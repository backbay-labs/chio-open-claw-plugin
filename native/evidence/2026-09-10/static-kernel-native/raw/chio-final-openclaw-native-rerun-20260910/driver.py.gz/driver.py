import subprocess,json,time,hashlib,os,signal
from pathlib import Path
root=Path('/tmp/chio-final-openclaw-native-rerun-20260910');root.mkdir(mode=0o700)
scriptroot=Path('/Users/connor/Medica/backbay/standalone/chio-open-claw-plugin/.worktrees/required-agent-integrations-20260909/native/test')
common=['--operator-state','/Users/connor/.local/share/chio-required-operators/final-openclaw-native-20260910/native','--package-dir','/tmp/chio-kernel-rc-consumers-20260910/openclaw/consumer/node_modules/@chio/openclaw-kernel','--image','sha256:7f925d68ced724f4a6314ab76dc117e9000515ba62149ee971a11c510be6637f','--model-auth-file','/Users/connor/.local/share/chio-required-operators/native-subscription-auth-20260909/codex/profile/auth.json','--require-watchdog-cleanup']
(root/'driver.py').write_bytes(Path(__file__).read_bytes());rows=[]
for case,script,flag,injector in [('result-substitution','qualify-http-host.py','--result-fault-injector','substitute-host-result.mjs'),('gateway-crash','qualify-http-host.py','--fault-injector','crash-host-gateway.mjs')]:
 cmd=['/opt/homebrew/opt/python@3.14/bin/python3.14',str(scriptroot/script),*common,'--cases',case,flag,'/Users/connor/Medica/backbay/standalone/arc/.worktrees/required-agent-integrations-20260909/scripts/acceptance/'+injector,'--output',str(root/case)]
 digest=hashlib.sha256((scriptroot/script).read_bytes()).hexdigest();(root/script).write_bytes((scriptroot/script).read_bytes());started=time.monotonic();timed=False;cleanup=[]
 with (root/(case+'.stdout')).open('w') as out,(root/(case+'.stderr')).open('w') as err:
  child=subprocess.Popen(cmd,stdout=out,stderr=err,start_new_session=True)
  try:code=child.wait(timeout=1200)
  except subprocess.TimeoutExpired:
   timed=True
   for sig,grace in [(signal.SIGTERM,15),(signal.SIGKILL,10)]:
    try:os.killpg(child.pid,sig)
    except ProcessLookupError:pass
    except OSError as e:cleanup.append(type(e).__name__)
    try:child.wait(timeout=grace);break
    except subprocess.TimeoutExpired:cleanup.append('wait timeout')
   code=child.poll()
 rows.append({'case':case,'command':cmd,'exitCode':code,'timedOut':timed,'processGroup':child.pid,'cleanupErrors':cleanup,'elapsedSeconds':time.monotonic()-started,'harnessSha256':digest,'harnessUnchanged':hashlib.sha256((scriptroot/script).read_bytes()).hexdigest()==digest,'liveInference':True});(root/'runs.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows[-1]),flush=True)
 if timed:raise RuntimeError('same-owner work stopped after timeout; preserve original state')
