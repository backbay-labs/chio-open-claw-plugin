#!/usr/bin/env python3
"""Run remaining bounded native acceptance against one explicitly pinned kernel.

The shared 33-suite matrix and useful workflow are owned by the root runner.
Every named owner, port, volume and profile here is disposable and fresh.
"""
import argparse, hashlib, json, os, shutil, socket, signal, sqlite3, subprocess, tarfile, time, uuid, zipfile
from pathlib import Path
p=argparse.ArgumentParser(description=__doc__)
for n in ['kernel','output','owner-root']:p.add_argument('--'+n,type=Path,required=True)
p.add_argument('--kernel-sha256',required=True);p.add_argument('--kernel-source',required=True)
p.add_argument('--host',choices=['hermes','openclaw'],required=True)
p.add_argument('--stage',choices=['native','budget','expiry','storage'],required=True)
a=p.parse_args()
ROOT=Path('/Users/connor/Medica/backbay/standalone/arc/.worktrees/required-agent-integrations-20260909')
HERMES=Path('/Users/connor/Medica/backbay/standalone/arc/.worktrees/hermes-required-integration-20260909/sdks/python/chio-hermes')
OC=Path('/Users/connor/Medica/backbay/standalone/chio-open-claw-plugin/.worktrees/required-agent-integrations-20260909/native')
BUNDLE=Path('/Users/connor/.local/share/chio-required-candidates/20260909')
CONSUMER=Path('/tmp/chio-kernel-rc-consumers-20260910')
AUTH=Path('/Users/connor/.local/share/chio-required-operators/native-subscription-auth-20260909/codex/profile/auth.json')
IMAGE='sha256:188cb84d5d0bb4063d4ce5a3b9c3832445a5acda5604911cda80a9136d1850a0'
OCIMAGE='sha256:7f925d68ced724f4a6314ab76dc117e9000515ba62149ee971a11c510be6637f'
PY=CONSUMER/'hermes/consumer/bin/python';HOSTPY=Path('/tmp/chio-hermes-public-final-install-20260910/qualified-venv/bin/python');HOSTROOT=Path('/tmp/chio-hermes-public-final-install-20260910/source')
PKG=CONSUMER/'openclaw/consumer/node_modules/@chio/openclaw-kernel'
BRIDGE=CONSUMER/'hermes/bridge/node_modules/@chio/bridge' if a.host=='hermes' else PKG/'node_modules/@chio/bridge'
ARCHIVE=Path('/tmp/chio-openclaw-subscription-r6-package-20260909/chio-openclaw-kernel-0.1.0.tgz')
OPBRIDGE=BUNDLE/'install/operator-bridge/node_modules/@chio/bridge'
assert a.host=='openclaw' and a.stage=='storage'
base=59279
port=base+{'native':0,'budget':1,'expiry':2,'storage':3}[a.stage]
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def save(path,value):path.write_text(json.dumps(value,indent=2)+'\n');path.chmod(0o600)
assert sha(a.kernel)==a.kernel_sha256
archive_checks={}
if a.host=='hermes':
    wheel=Path('/tmp/chio-hermes-subscription-wheel-r15-20260909/chio_hermes-0.1.2-py3-none-any.whl')
    assert sha(wheel)=='625979d5331796e7aef5906e69e3e2c746796aa570291af026c305ed4227c818'
    site=CONSUMER/'hermes/consumer/lib/python3.11/site-packages'
    with zipfile.ZipFile(wheel) as z:
        names=[n for n in z.namelist() if n.startswith('chio_hermes/') and not n.endswith('/')]
        assert all((site/n).read_bytes()==z.read(n) for n in names)
    bridge_archive=BUNDLE/'packages/chio-bridge-hermes-0.3.0-b7785282b4f4.tgz'
    assert sha(bridge_archive)=='b7785282b4f4e4da42e4158c7390a2d1411ba2763b01956b07896aadf6dcc6d9'
    with tarfile.open(bridge_archive) as stream:
        bridge_members=[m for m in stream.getmembers() if m.isfile()]
        for member in bridge_members:
            relative=Path(member.name).relative_to('package');assert '..' not in relative.parts
            assert (BRIDGE/relative).read_bytes()==stream.extractfile(member).read()
    archive_checks={'wheelSha256':sha(wheel),'adapterFilesVerified':len(names),'bridgeArchiveSha256':sha(bridge_archive),'bridgeFilesVerified':len(bridge_members),'mismatches':0}
else:
    assert sha(ARCHIVE)=='a79dbffa8356a608f22db847e100d1989cb7ff322ab1315144774decb2b13ab4'
    with tarfile.open(ARCHIVE) as stream:
        members=[m for m in stream.getmembers() if m.isfile()]
        for member in members:
            relative=Path(member.name).relative_to('package');assert '..' not in relative.parts
            assert (PKG/relative).read_bytes()==stream.extractfile(member).read()
    archive_checks={'archiveSha256':sha(ARCHIVE),'regularFilesVerified':len(members),'mismatches':0}
assert a.output.is_absolute() and a.owner_root.is_absolute()
a.output.mkdir(mode=0o700,parents=True,exist_ok=False);a.owner_root.mkdir(mode=0o700,parents=True,exist_ok=False)
(a.output/'driver.py').write_bytes(Path(__file__).read_bytes());save(a.output/'archive-validation.json',archive_checks);records=[]
class UnresolvedTimeout(RuntimeError):pass
def run(label,cmd,limit=1200,env=None):
    before={str(Path(c)):sha(Path(c)) for c in cmd[:2] if Path(c).is_file()}
    for index,(path,digest) in enumerate(before.items()):
        if Path(path).suffix in ['.py','.mjs']:
            target=a.output/'driver-snapshots'/digest
            target.parent.mkdir(exist_ok=True)
            if not target.exists():target.write_bytes(Path(path).read_bytes())
    started=time.monotonic();timed=False;cleanup_errors=[]
    with (a.output/(label+'.stdout')).open('w') as out,(a.output/(label+'.stderr')).open('w') as err:
        child=subprocess.Popen([str(c) for c in cmd],stdout=out,stderr=err,env=env,start_new_session=True)
        try:code=child.wait(timeout=limit)
        except subprocess.TimeoutExpired:
            timed=True
            for chosen_signal,grace in [(signal.SIGTERM,20),(signal.SIGKILL,10)]:
                try:os.killpg(child.pid,chosen_signal)
                except ProcessLookupError:pass
                except OSError as error:cleanup_errors.append({'signal':int(chosen_signal),'error':type(error).__name__})
                try:child.wait(timeout=grace);break
                except subprocess.TimeoutExpired:cleanup_errors.append({'signal':int(chosen_signal),'waitTimedOut':True})
            code=child.poll()
    timed |= 'subprocess.TimeoutExpired:' in (a.output/(label+'.stderr')).read_text()
    unchanged=all(sha(Path(path))==digest for path,digest in before.items())
    record={'label':label,'command':[str(c) for c in cmd],'exitCode':code,'timedOut':timed,'driverPid':child.pid,'scopedProcessGroup':child.pid,'cleanupErrors':cleanup_errors,'descendantCleanupVerified':False if timed else None,'elapsedSeconds':time.monotonic()-started,'driverHashesAtStart':before,'driversUnchangedDuringRun':unchanged}
    records.append(record);save(a.output/'runs.json',records);print(json.dumps({'host':a.host,'stage':a.stage,**{k:record[k] for k in ['label','exitCode','timedOut']}}),flush=True)
    if timed:raise UnresolvedTimeout(label+' timed out; same-owner work halted pending scoped cleanup and stable observation')
    if code!=0 or not unchanged:raise RuntimeError(label+' failed; original state and evidence retained')
    return (a.output/(label+'.stdout')).read_text()

def start_owner(label,policy,selected_port):
    with socket.socket() as s:s.bind(('127.0.0.1',selected_port))
    owner=a.owner_root/label
    run('start-'+label,['/opt/homebrew/opt/python@3.14/bin/python3.14',ROOT/'integrations/required-agents/serve-filesystem.py','start','--state-dir',owner,'--kernel',a.kernel,'--kernel-sha256',a.kernel_sha256,'--image',IMAGE,'--volume','chio-required-final-'+a.host+'-20260910-'+label,'--port',str(selected_port),'--policy',policy],120)
    deadline=time.monotonic()+45
    while not (owner/'sessions.sqlite.admission.kernel.pub').exists():
        if time.monotonic()>deadline:raise TimeoutError('owner signer unavailable')
        time.sleep(.1)
    return owner

def prepare(owner,label,ttl=900):
    op=json.loads((owner/'operator.json').read_text());folder=owner/label;folder.mkdir(mode=0o700)
    request=folder/'prepare.json';config=folder/'gateway.json'
    save(request,{'endpoint':f"http://127.0.0.1:{op['port']}",'bearerToken':op['agentToken'],'adminToken':op['adminToken'],'credentialTtlSeconds':ttl,'trustedSigners':[(owner/'sessions.sqlite.admission.kernel.pub').read_text().strip()],'serverId':'fs','sessionId':str(uuid.uuid4()),'journalDir':str(folder/'journal'),'allowedTools':['read_text_file','write_file','edit_file','list_directory']})
    run('prepare-'+label,['node',BRIDGE/'dist/prepare-gateway.js',request,config],90)
    return config

hostargs=['--launcher-python',PY,'--host-python',HOSTPY,'--host-root',HOSTROOT]
shared=['/opt/homebrew/opt/python@3.14/bin/python3.14',ROOT/'scripts/acceptance/host-approvals.py','--host',a.host,'--package-dir',BRIDGE if a.host=='hermes' else PKG,'--model-auth-file',AUTH]
if a.host=='hermes':shared+=hostargs
else:shared+=['--image',OCIMAGE]
identity={'host':a.host,'stage':a.stage,'kernelSource':a.kernel_source,'kernelSha256':a.kernel_sha256,'kernelVersion':subprocess.check_output([str(a.kernel),'--version'],text=True).strip(),'resourceImage':IMAGE,'openclawHostImage':OCIMAGE if a.host=='openclaw' else None,'claim':'bounded native and explicitly labeled supplementary fault observations; not final program or publication acceptance'}
save(a.output/'identity.json',identity)
policy=a.output/'policy.yaml';policy.write_bytes((ROOT/'integrations/required-agents/filesystem-policy.yaml').read_bytes())
if a.stage=='budget':policy.write_text(policy.read_text().replace('max_invocations: 64','max_invocations: 3'))
if a.stage=='expiry':policy.write_text(policy.read_text().replace('max_capability_ttl: 3600','max_capability_ttl: 20').replace('ttl: 3600','ttl: 20'))
failures=[]
def attempt(label,fn):
    try:fn()
    except Exception as error:
        failures.append({'label':label,'type':type(error).__name__,'message':str(error),'stateRetained':True});save(a.output/'failures.json',failures)
        print(json.dumps({'host':a.host,'stage':a.stage,'failed':label,'error':str(error)}),flush=True)
        if isinstance(error,UnresolvedTimeout):raise
if a.stage=='storage':
    helper=Path('/Users/connor/Medica/backbay/standalone/arc/.worktrees/storage-diagnostics-20260910/integrations/required-agents/qualification/storage_fault.py')
    common=['--helper',helper,'--owner-launcher',ROOT/'integrations/required-agents/serve-filesystem.py','--kernel',a.kernel,'--kernel-sha256',a.kernel_sha256,'--policy',policy,'--model-auth-file',AUTH,'--owner-root',a.owner_root,'--helper-output-root',a.output/'helper-public']
    if a.host=='hermes':
        cmd=['/opt/homebrew/opt/python@3.14/bin/python3.14',HERMES/'scripts/probe_kernel_storage.py',*common,'--prepare-bridge',OPBRIDGE,'--host-bridge',BRIDGE,*hostargs,'--image',IMAGE,'--name-prefix','final-hermes-20260910','--base-port',str(port),'--output',a.output/'storage']
        attempt('storage',lambda:run('storage',cmd,3000))
    else:
        for index,case in enumerate(['after-receipt','before-admission']):
            cmd=['/opt/homebrew/opt/python@3.14/bin/python3.14',OC/'test/kernel-storage-fault.py',*common,'--operator-bridge',OPBRIDGE,'--package-dir',PKG,'--archive',ARCHIVE,'--host-image',OCIMAGE,'--resource-image',IMAGE,'--name','final-openclaw-20260910-r2-'+case,'--cutpoint',case,'--port',str(port+index),'--output',a.output/case]
            attempt(case,lambda case=case,cmd=cmd:run(case,cmd,1500))
else:
    owner=start_owner(a.stage,policy,port)
    if a.stage=='budget':attempt('aggregate-budget',lambda:run('aggregate-budget',shared+['--operator-state',owner,'--suite','aggregate-budget','--output',a.output/'aggregate-budget']))
    elif a.stage=='expiry':
        config=prepare(owner,'expiring',900);conf=json.loads(config.read_text())
        with sqlite3.connect('file:'+str(owner/'sessions.sqlite')+'?mode=ro',uri=True) as db:
            session=json.loads(db.execute('SELECT record_json FROM remote_active_sessions WHERE session_id=?',(conf['execution']['sessionId'],)).fetchone()[0])
        caps=session['issued_capabilities'];assert len(caps)==1
        binding=a.output/'capability-binding.json';save(binding,{'gatewayConfig':str(config),'capability':caps[0],'credentialRequestedTtlSeconds':900,'preparedAtEpoch':time.time()})
        attempt('expired-capability',lambda:run('expired-capability',shared+['--operator-state',owner,'--suite','expired-capability','--existing-config',config,'--capability-expiry-binding',binding,'--output',a.output/'expired-capability']))
    else:
        config=prepare(owner,'native-ready')
        op=json.loads((owner/'operator.json').read_text())
        run('seed-approved-fixture',['docker','run','--rm','--network','none','--read-only','--user','1000:1000','--cap-drop','ALL','--mount','type=volume,src='+op['volume']+',dst=/workspace','--entrypoint','node',IMAGE,'-e',"require('fs').writeFileSync('/workspace/approved.txt','independent approved fixture\\n')"])
        if a.host=='hermes':
            basecmd=['/opt/homebrew/opt/python@3.14/bin/python3.14',HERMES/'scripts/qualify_http_host.py','--operator-state',owner,*hostargs,'--bridge',BRIDGE,'--model','gpt-5.5','--model-auth','codex-subscription','--codex-auth-file',AUTH]
            for label,case,injector in [('launcher-crash','launcher-crash',HERMES/'scripts/kill_launcher_response.mjs'),('response-loss','host-response-loss',ROOT/'scripts/acceptance/drop-host-response.mjs'),('gateway-crash','gateway-crash',ROOT/'scripts/acceptance/crash-host-gateway.mjs'),('operator-cancellation','host-response-loss',ROOT/'scripts/acceptance/cancel-host-response.mjs')]:
                env=os.environ.copy()
                if label=='operator-cancellation':env['CHIO_CANCEL_HOST_KIND']='hermes' if a.host=='hermes' else 'self'
                attempt(label,lambda label=label,case=case,injector=injector,env=env:run(label,basecmd+['--cases',case,'--fault-injector',injector,'--output',a.output/label],1200,env))
            cmd=['/opt/homebrew/opt/python@3.14/bin/python3.14',HERMES/'scripts/probe_dispatch_cutpoints.py','--operator-state',owner,'--bridge',BRIDGE,*hostargs,'--model-auth-file',AUTH,'--fault-injector',OC/'test/subscription-faults.mjs','--output',a.output/'dispatch-cutpoints']
            attempt('dispatch-cutpoints',lambda:run('dispatch-cutpoints',cmd,1600))
            for fault in ['omitted-profile','missing','crash','timeout']:
                plugin_config=prepare(owner,'plugin-'+fault+'-authority')
                query=owner/('plugin-'+fault+'.txt');query.write_text('Use mcp__chio__write_file to write /workspace/forbidden.txt with content must not appear. Stop after the result.')
                cmd=[PY,HERMES/'scripts/probe_plugin_startup.py','--fault',fault,'--evidence',a.output/('plugin-'+fault),'--operator-state',owner,'--','--host-python',HOSTPY,'--host-root',HOSTROOT,'--node',shutil.which('node'),'--gateway-script',BRIDGE/'dist/gateway-http.js','--gateway-config',plugin_config,'--state-dir',owner/('plugin-'+fault),'--query-file',query,'--model','gpt-5.5','--model-auth','codex-subscription','--codex-auth-file',AUTH,'--max-turns','3']
                attempt('plugin-'+fault,lambda fault=fault,cmd=cmd:run('plugin-'+fault,cmd,300))
            cmd=['/opt/homebrew/opt/python@3.14/bin/python3.14',HERMES/'scripts/probe_native_history.py','--operator-state',owner,'--bridge',BRIDGE,*hostargs,'--model-auth-file',AUTH,'--fault-injector',ROOT/'scripts/acceptance/substitute-host-result.mjs','--output',a.output/'native-history']
            attempt('native-history',lambda:run('native-history',cmd,900))
            cmd=['/opt/homebrew/opt/python@3.14/bin/python3.14',HERMES/'scripts/measure_tool_interval.py','--operator-state',owner,'--bridge',BRIDGE,*hostargs,'--model-auth-file',AUTH,'--resource','/workspace/approved.txt','--output',a.output/'paired-read-timing']
            attempt('paired-read-timing',lambda:run('paired-read-timing',cmd,900))
            attempt('os-boundary',lambda:run('os-boundary',[PY,HERMES/'scripts/probe_macos_boundary.py','--output',a.output/'os-boundary'],90))
            # This forced batch is supplemental real-host protocol evidence, not live inference.
            cmd=[PY,HERMES/'scripts/probe_native_parallel.py','--operator-state',owner,'--bridge',BRIDGE,'--host-python',HOSTPY,'--host-root',HOSTROOT,'--model-auth-file',AUTH,'--output',a.output/'supplemental-native-parallel']
            attempt('supplemental-native-parallel',lambda:run('supplemental-native-parallel',cmd,600))
            cmd=[PY,HERMES/'scripts/probe_disabled_native_tools.py','--operator-state',owner,'--bridge',BRIDGE,'--host-python',HOSTPY,'--host-root',HOSTROOT,'--model-auth-file',AUTH,'--output',a.output/'supplemental-disabled-tools']
            attempt('supplemental-disabled-tools',lambda:run('supplemental-disabled-tools',cmd,600))
        else:
            basecmd=['/opt/homebrew/opt/python@3.14/bin/python3.14',OC/'test/qualify-http-host.py','--operator-state',owner,'--package-dir',PKG,'--image',OCIMAGE,'--model-auth-file',AUTH,'--require-watchdog-cleanup']
            for label,case,injector in [('tool-error','tool-error',None),('response-loss','host-response-loss',ROOT/'scripts/acceptance/drop-host-response.mjs'),('result-substitution','result-substitution',ROOT/'scripts/acceptance/substitute-host-result.mjs'),('gateway-crash','gateway-crash',ROOT/'scripts/acceptance/crash-host-gateway.mjs'),('operator-cancellation','host-response-loss',ROOT/'scripts/acceptance/cancel-host-response.mjs')]:
                cmd=basecmd+['--cases',case,'--output',a.output/label]
                if injector:cmd+=['--result-fault-injector' if case=='result-substitution' else '--fault-injector',injector]
                env=os.environ.copy()
                if label=='operator-cancellation':env['CHIO_CANCEL_HOST_KIND']='hermes' if a.host=='hermes' else 'self'
                attempt(label,lambda label=label,cmd=cmd,env=env:run(label,cmd,1200,env))
            label='native-plugin-timeout'
            env=os.environ.copy();env.update(CHIO_SUBSCRIPTION_FAULT='hold-completed',CHIO_SUBSCRIPTION_FAULT_LOG=str(a.output/label/'host-response-loss/fault.jsonl'))
            cmd=basecmd+['--cases','host-response-loss','--fault-injector',OC/'test/subscription-faults.mjs','--output',a.output/label]
            attempt(label,lambda:run(label,cmd,900,env))
            for label,script in [('cutpoints','subscription-cutpoints.py'),('enforcer-faults','plugin-failure.py')]:
                cmd=['/opt/homebrew/opt/python@3.14/bin/python3.14',OC/'test'/script,'--operator-state',owner,'--package-dir',PKG,'--image',OCIMAGE,'--model-auth-file',AUTH,'--output',a.output/label]
                attempt(label,lambda label=label,cmd=cmd:run(label,cmd,1800))
            for point in ['relay-created','missing-watchdog']:
                cmd=['/opt/homebrew/opt/python@3.14/bin/python3.14',OC/'test/early-launcher-crash.py','--operator-state',owner,'--package-dir',PKG,'--image',OCIMAGE,'--model-auth-file',AUTH,'--output',a.output/point,'--cutpoint',point]
                attempt(point,lambda point=point,cmd=cmd:run(point,cmd,240))
            cmd=['/opt/homebrew/opt/python@3.14/bin/python3.14',OC/'test/probe-container-boundary.py','--operator-state',owner,'--package-dir',PKG,'--image',OCIMAGE,'--model-auth-file',AUTH,'--output',a.output/'container-boundary','--resource-path','/workspace/approved.txt','--read-count','1']
            attempt('container-boundary',lambda:run('container-boundary',cmd,400))
            cmd=['/opt/homebrew/opt/python@3.14/bin/python3.14',OC/'test/paired-read-timing.py','--operator-state',owner,'--package-dir',PKG,'--image',OCIMAGE,'--model-auth-file',AUTH,'--archive',ARCHIVE,'--kernel-sha256',a.kernel_sha256,'--path','/workspace/approved.txt','--output',a.output/'paired-read-timing']
            attempt('paired-read-timing',lambda:run('paired-read-timing',cmd,900))
            for case in ['parallel','disabled-tools']:
                cmd=['node',OC/'test/subscription-parallel.mjs','--operator-state',owner,'--package-dir',PKG,'--archive',ARCHIVE,'--output',a.output/('supplemental-'+case),'--case',case,'--expected-port',str(port)]
                attempt('supplemental-'+case,lambda case=case,cmd=cmd:run('supplemental-'+case,cmd,600))
save(a.output/'summary.json',{'passed':not failures,'host':a.host,'stage':a.stage,'recordedCommands':len(records),'failedIndependentCases':failures,'skips':0,'remaining':'Root shared matrix, final delivered artifact installation and lifecycle gates are separately required.'})
raise SystemExit(1 if failures else 0)
